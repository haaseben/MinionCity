/**
* \file TileVisitor.cpp
*
* \author Ben Haase
*/
#include "stdafx.h"
#include "TileVisitor.h"


CTileVisitor::CTileVisitor()
{
}


CTileVisitor::~CTileVisitor()
{
}
